
	double
ran1()
{
	double drand48();
	return( drand48() );
}

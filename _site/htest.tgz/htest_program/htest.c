#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAXLINE 5000

char line[MAXLINE];
main(int argc,char *argv[])
{
  int tsam, segs, nsites, i, j, k, pd=0, ph=0, obs, npop, *popsize, loops;
  double r, alpha, t0, m, pi, h, w, opi, ow, oh, bm, an, bn, bn1, td, fwh, fwh_old, a2, b1, b2, c1, c2, e1, e2;
  char **sample, inbuf[MAXLINE];
  char *buffer = NULL;
  FILE *fopen();
  setbuf(stdout,buffer);
  
  fgets(line,MAXLINE,stdin);
  fscanf(stdin,"%d",&npop);
  popsize = (int *)malloc((npop+1)*sizeof(int));
  
  for(i=0,tsam=0;i<npop;i++){
    fscanf(stdin,"%d", &popsize[i]);
    tsam+=popsize[i];
  }
  fscanf(stdin,"%d %d %lf %lf",&nsites,&segs,&r,&alpha);
  

  
  if(alpha > 0){
    fscanf(stdin,"%lf",&t0);
  }
  if(npop>1){
    fscanf(stdin,"%lf",&m);
  }
  fscanf(stdin,"%d",&loops);
  fgets(line,MAXLINE,stdin);
  

  if( !(sample = (char **)malloc((loops+1)*(tsam+1)*sizeof(char*))))
    fprintf(stdout,"allocation memory error\n");
  for(i=0;i<tsam;i++){
    if( !(sample[i] = (char *)malloc((loops*segs+1)*sizeof(char))))
      fprintf(stdout,"allocation memory error\n");
  }

  observed(tsam, npop, segs, &opi, &oh, &bm, &an);

  fprintf(stdout,"\nBack-mutation: %lf\n",bm);
  for(i=1, bn=0;i<tsam;i++) bn+=1.0/((double) pow(i,2.0));
  for(i=1, bn1=0;i<tsam+1;i++) bn1+=1.0/((double) pow(i,2.0));
  for(i=1, a2=0;i<tsam;i++) a2+=1.0/((double) i*i);
  b1 = (tsam+1)/(3.0*(tsam-1));
  b2 = 2*(tsam*tsam+tsam+3)/(9.0*tsam*(tsam-1));
  c1 = b1 - 1.0/an;
  c2 = b2 - (tsam+2.0)/(1.0*tsam*an) + a2/(an*an);
  e1 = c1/an;
  e2 = c2/(an*an + a2);
  w=((double) segs)/an;
  td = (opi-w)/sqrt(e1*segs+e2*segs*(segs-1)); 
  fwh = 0.5*(opi-oh)/sqrt((tsam-2)*w/(6*(tsam-1)) + (18*tsam*tsam*(tsam*3+2)*bn1-(88*pow(tsam,3.0)+9*tsam*tsam-13*tsam+6))*(segs*(segs-1)/(an*an+bn))/(9*tsam*(tsam-1)*(tsam-1)));
  fwh_old = opi-oh;
  for(i=0;i<loops;i++){
    fscanf(stdin,"%d",&segs);
    fgets(line,MAXLINE,stdin);
    for(j=0;j<(segs-segs%10)/10;j++){
      fgets(line,MAXLINE,stdin);
    }
    if(segs%10!=0){
      fgets(line,MAXLINE,stdin);
    } 
    
    for(j=0;j<tsam;j++){
      fscanf(stdin,"%s",sample[j]);
      
    }
    stats(sample, tsam, segs, bm, &pi, &h);
   
    if( (pi-w)<=(opi-w) ) pd++;
    if( (pi-h)<=(opi-oh) ) ph++;
    fgets(line,MAXLINE,stdin);
  }
  fprintf(stdout,"Observed: Theta(w) = %lf, Theta(pi) = %lf, Theta(h) = %lf\n",w,opi,oh);
  fprintf(stdout,"Tajima's D: %f, Probability(one-tailed): %f\n",td,(((double) pd)/((double) loops)) );
  fprintf(stdout,"Fay & Wu's H: %f, Probability(one-tailed): %f\n",fwh,(((double) ph)/((double) loops)) );
  fprintf(stdout,"Fay & Wu's H (unscaled): %f, Probability(one-tailed): %f\n",fwh_old,(((double) ph)/((double) loops)) );

  fflush(NULL);
  fclose(stdout);
}

int stats(char **sample, int tsam, int segs, double bm, double *pi, double *h){
  
  int i, j, k, site, noc, obs[2*tsam], nobs[tsam-1];
  char state;
  
  *pi=0;
  *h=0;
  state = '1'; 
  for(site=0;site<segs;site++){
    for(i=0,noc=0;i<tsam;i++){
      if(rand()>bm)
	noc+=(sample[i][site]== state ? 1:0);
      else
	noc+=(sample[i][site]== state ? 0:1);
    }
    *pi+=((double) 2*noc*(tsam-noc))/((double) tsam*(tsam-1));
    *h+=((double) 2*noc*noc)/((double) tsam*(tsam-1));
  }
}



int observed(int tsam, int npop, int segs, double *opi, double *oh, double *bm, double *an){
  int i, j, obs[2*tsam], nobs[tsam-1];
  char state,eofm;
  FILE *pf, *fopen();

  pf = fopen("poly.dat","r");
  fscanf(pf,"%lf ",bm);
  fprintf(stdout,"Observed data: ",bm);
  for(i=1,j=0;i<tsam;i++){
    if(fscanf(pf,"%d",&obs[i])==EOF) {
      fprintf(stdout,"\n1. poly.dat does not match input\n"); 
      exit(0);
    }
    j+=obs[i];
    fprintf(stdout,"%d ",obs[i]);
  }
  if(j!=segs) {
    fprintf(stdout,"\n2. poly.dat does not match input\n");
    exit(0);
  }
  
  
  if( ((j=getc(pf)) != EOF)) {
    eofm=j;
    if((isdigit(j))){
      fprintf(stdout,"\n3. poly.dat does not match input"); 
      exit(0);
    }
  }

  
  for(i=1, *an=0;i<tsam;i++) *an+=1.0/((double) i);
  for(*opi=0.0,*oh=0.0,i=1;i<tsam;i++) {
    *opi+=((double) obs[i]*2*i*(tsam-i))/((double) tsam*(tsam-1));
    *oh+=((double) obs[i]*2*i*i)/((double) tsam*(tsam-1));
  }
}

/***** ms.c     ************************************************
*
*       Generates samples of gametes ( theta given) .
*       Usage:
*   mss npop sample[1] ... sample[npop] nsites  ss  r alphag t0 (mig_rate if
                                                               npop>1)  howmany

*       where these arguments are :
           npop:  Number of subpopulations which make up the total population
           sample[i]: the sample size from the i th subpopulation (can be zero.)
           nsites: number of sites between which recombination can occur.
	   ss:  number of segregating sites
           r: recombination rate between ends of segment times 4No
	   alphag:  growth rate of population after time t0.  
	   t0:  the time in units of 4No generations from the present at which
		 exponential population growth begins. (This argument is included
		on the command line only if alphag != zero. )
		(If we denote current population size by No, then
		N(t) = No*exp(-alphag*t), for t<t0,
		and N(t) = No*exp(-alphag*t0) for t>t0 , t being measured in all
		cases in units of 4No generations. The present is t=0.) 
           mig_rate: migration rate: the fraction of each subpop made up of
                 migrants times 4No. (This argument is left off if npop is one.)
           howmany: howmany samples to generate.

	Note:  In the above definition, No is the total diploid population if
		npop is one, otherwise, No is the diploid population size of each
		subpopulation.
	A seed file called "seedms" must be present, containing three integers. These
		numbers will be modified by the program. So subsequent runs
		will produce new output.  The initial contents of seedms will be
		printed on the first line of the output.
        Output consists of one line with the command line arguments and the seeds.
		The samples appear sequentially following that line.
		Each sample begins with the number of segregating sites, the positions
		of the segregating sites (on a scale of 0.0 - 1.0). On the following
		lines are the sampled gametes, with mutants alleles represented as
		ones and ancestral alleles as zeros.
	To compile:  cc -o ms  ms.c mg.c stree.c subs1.c ran1.c -lm

example runs:  ms 2 4 3 1000 12 1.0 1.5 0.5 0.5  3 >sample3.out
   with seedms: 18989 25603 42482 
	example 2: ms  1  5 1000 7  1.0 0.5 1.5  3  >sample.out
	with seedms: 1589 40494 54310  
	   produces the output in sample.out.  In this case, samples of size five
	   are drawn from a panmictic
	   population , with 1000 sites between which recombination can occur,
	   each sample with 7 seg sites,4Nr=1.0, alphag=0.5, t0=1.5, and 3 samples generated.
*
***************************************************************************/


#include "my.h"

#define SITESINC 10 
#define SSMAX 1000

unsigned maxsites = SITESINC ;

struct node{
	int abv;
	int ndes;
	float time;
	};

struct segl {
	int beg;
	struct node *ptree;
	int next;
	};

double *posit ;

main(argc,argv)
        int argc;
        char *argv[];
{
        int nsam ,nsites, i, ns, howmany, npop, *config, pop, count, narg; 
     double  theta, r,  mig_rate, estimator, gst, alpha, within, between;
        char **list, **cmatrix();
        FILE *pf, *fopen(), *pfseed ;
        struct runsum  est_m, gst_m, within_m, between_m ;
        double ttot, alphag, t0 ;
        int  segsites ;
       unsigned short seedv[3], *pseed, *seed48() ;

        if( argc ==1 ) {
 printf("Usage: \nmss npop samplesize[1] ... samplesize[npop] nsites ");
        printf("ss  r alpha t0(if alpha!=0.0) (migrate if npop>1) howmany\n");
        exit(0);
        }
        npop = atoi( argv[1] );
        config = (int *)malloc((unsigned)((npop+1)*sizeof(int)));
        for( pop=0, narg=1 ; pop<npop; pop++) {
           config[pop] = atoi( argv[++narg] );
                if( config[pop] < 0 ) break;
           }
        nsites = atoi( argv[++narg]);
	segsites = atoi( argv[++narg] ) ;
        r = atof( argv[++narg]);
        alphag = atof( argv[++narg]);
        if( alphag != 0.0 ) t0 = atof( argv[++narg]);
        if( npop > 1 )  mig_rate = atof( argv[++narg]);
        else mig_rate = 0.0 ;
        howmany = atoi( argv[++narg]);

      pfseed = fopen("seedms","r");
 if( pfseed == NULL ) { fprintf(stderr,"no seedms file?\n"); exit( 0) ;}
        for(i=0;i<3;i++) fscanf(pfseed," %hd",seedv+i);
        fclose( pfseed);
        seed48( seedv );

        while( pop<npop ){ config[pop++]=0 ;  }
        pf = stdout ;
        alpha = npop/(npop-1.);
        alpha *= alpha ;
        nsam = 0 ;
        for(i=0;i<npop; i++) nsam += config[i] ;

        printf("\n%d  ",npop);
        for(pop=0; pop<npop; pop++){   printf("%d ",config[pop]); }
        printf("%d ",nsites);
                printf("%d ", segsites);
        printf("%f %lf ",r, alphag);
	if( alphag != 0.0 ) printf(" %lf  ",t0) ;
        if( npop > 1) { printf("%f  ",mig_rate);}
        printf("%d %d %d %d\n",howmany, seedv[0], seedv[1], seedv[2] );
	maxsites = segsites + 2 ;
        list = cmatrix(nsam,maxsites+1);
	posit = (double *)malloc( (unsigned)( maxsites *sizeof( double)) ) ;

        count=0;
    while( howmany-count++ ) {
        gensam(npop,nsam,config,nsites, segsites ,r,mig_rate,list,alphag,t0);
       fprintf(pf,"\n");
          fprintf(pf,"\n%d",segsites);
        for( i=0; i<segsites; i++){
            if( i%10 == 0 ) fprintf(pf,"\n");
            fprintf(pf,"%6.4lf ",posit[i] );
            }
       fprintf(pf,"\n");
   
       for(i=0;i<nsam; i++)  fprintf(pf,"%s\n",  list[i]  ); 
	}
        pfseed = fopen("seedms","w");
        pseed = seed48(seedv);
        fprintf(pfseed,"%d %d %d\n",pseed[0], pseed[1],pseed[2]);
}



	int 
gensam( npop,nsam,inconfig, nsites, segsites, r,mig_rate,list, alphag,t0)
	int npop,nsam,inconfig[], nsites , segsites ;
	char **list;
	double  r, mig_rate,  alphag, t0;
{
	int nsegs, h, i, k, j, seg, ns, start, end, len, segsit ;
	struct segl *seglst, *segtre_mig() ; /* used to be: [MAXSEG];  */
	double nsinv,  tseg, tt, ttime() ;
	double *pk ;
	int *ss ;


	nsinv = 1./nsites;
	seglst = segtre_mig(npop,nsam,inconfig,nsites,r,mig_rate, &nsegs, alphag,t0) ;
	
        pk = (double *)malloc((unsigned)(nsegs*sizeof(double)));
        ss = (int *)malloc((unsigned)(nsegs*sizeof(int)));
        if( (pk==NULL) || (ss==NULL) ) perror("malloc error. gensam.2");


	tt = 0.0 ;
	for( seg=0, k=0; k<nsegs; seg=seglst[seg].next, k++) { 
		end = ( k<nsegs-1 ? seglst[seglst[seg].next].beg -1 : nsites-1 );
		start = seglst[seg].beg ;
		len = end - start + 1 ;
		tseg = len/(double)nsites ;
               pk[k] = ttime(seglst[seg].ptree,nsam)*tseg ;
                tt += pk[k] ;
		}

       for (k=0;k<nsegs;k++) pk[k] /= tt ;
        mnmial(segsites,nsegs,pk,ss);
	ns = 0 ;
	for( seg=0, k=0; k<nsegs; seg=seglst[seg].next, k++) { 
		end = ( k<nsegs-1 ? seglst[seglst[seg].next].beg -1 : nsites-1 );
		start = seglst[seg].beg ;
		len = end - start + 1 ;
                tseg = len/(double)nsites;
                make_gametes(nsam,seglst[seg].ptree,tt*pk[k]/tseg, ss[k], ns, list);

		free(seglst[seg].ptree) ;
		locate(ss[k],start*nsinv, len*nsinv,posit+ns);   
		ns += ss[k] ;
		}
	for(i=0;i<nsam;i++) list[i][ns] = '\0' ;
	free(pk);
	free(ss);
	return( ns ) ;
}



/* allocates space for gametes (character strings) */
	char **
cmatrix(nsam,len)
	int nsam, len;
{
	int i;
	char **m;

	if( ! ( m = (char **) malloc( (unsigned) nsam*sizeof( char* ) ) ) )
	   perror("alloc error in cmatrix") ;
	for( i=0; i<nsam; i++) {
		if( ! ( m[i] = (char *) malloc( (unsigned) len*sizeof( char ) )))
			perror("alloc error in cmatric. 2");
		}
	return( m );
}



	int
locate(n,beg,len,ptr)
	int n;
	double beg, len, *ptr;
{
	int i;

	ordran(n,ptr);
	for(i=0; i<n; i++)
		ptr[i] = beg + ptr[i]*len ;

}

